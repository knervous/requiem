temp0 Advanced Map Parser v0.1.0

This utility is a local server that reads log files from your EverQuest directory. 
Extract all the contents of the zip file this was found in into your EQ log directory e.g. C:/Program Files/EverQuest/Logs

Be sure to use /log in-game to enable logging. You'll notice this working by seeing your character's logfile being updated in realtime.

To connect, visit https://eqmap.vercel.app where more info and updates will always be available